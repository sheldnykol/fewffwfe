import React, { useEffect, useState } from "react";

import { Routes, Route } from "react-router-dom";
// import { getItems, deleteItem, addItem } from "./api";

import Register from "./pages/Register";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Chat from "./pages/Chat";

function App() {
  return (
    // <div>
    // <AddItem />
    // <ItemList />
    <Routes>
      <Route path="/register" element={<Register />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/" element={<Chat />} /> 
    </Routes>

    // </div>
  );
}

// function ItemList() {
//     const [items, setItems] = useState([]);

//     useEffect(() => {
//         fetchItems();
//     }, [items]);

//     const fetchItems = async () => {
//         const { data } = await getItems();
//         setItems(data);
//     };

//     const handleDelete = async (id) => {
//         await deleteItem(id);
//         fetchItems();

//     };

//     return (
//         <div>
//             <h1>Item List</h1>
//             <ul>
//                 {items.map((item) => (
//                     <li key={item._id}>
//                         {item.name} - {item.description}
//                         <button onClick={() => handleDelete(item._id)}>Delete item</button>
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     )
// }

// function AddItem(){
//     const [name, setName] = useState('');
//     const [description, setDescription] = useState('');

//     const handleSubmit = async (e) => {
//         e.preventDefault(); //den tha se paei kapoy to href ths formas otan ginei submit
//         await addItem({ name, description});
//         setName('');
//         setDescription('');
//     };

//     return(
//         <form onSubmit={handleSubmit}>
//         <input
//             type="text"
//             value={name}
//             placeholder="Name"
//             onChange={(e) => setName(e.target.value)}
//         />

//                 <input
//                 type="text"
//                 value={description}
//                 placeholder="Description"
//                 onChange={(e) => setDescription(e.target.value)}
//             />
//             <button type="submit">Add Item</button>
//         </form>
//     )
// }
//REGISTER

//Login

//DASHBOARD

export default App;
