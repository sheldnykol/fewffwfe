import React, { useState } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";

const RoomSelection = () => {
  const [roomName, setRoomName] = useState("");
  const [error, setError] = useState("");
  const history = useHistory();

  const handleCreateRoom = async () => {
    try {
      const response = await axios.post(
        "http://localhost:5000/api/create-room",
        {
          roomName,
        }
      );
      history.push(`/chat/${response.data.roomName}`);
    } catch (err) {
      setError("Failed to create room");
    }
  };

  return (
    <div>
      <h2>Select or Create Room</h2>
      <input
        type="text"
        placeholder="Room Name"
        value={roomName}
        onChange={(e) => setRoomName(e.target.value)}
      />
      <button onClick={handleCreateRoom}>Create Room</button>
      {error && <p>{error}</p>}
    </div>
  );
};

export default RoomSelection;
