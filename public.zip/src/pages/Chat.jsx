import React, { useState, useEffect , useRef } from "react";
import { io } from "socket.io-client";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import styled from "styled-components";
import ChatContainer from "../ChatContainer";
import Contacts from "../Contacts";
import Welcome from "../Welcome";
import { allUsersRoute, host } from "../utils/APIRoutes";

function Chat() {
  const navigate = useNavigate();
  const socket = useRef();
  const [contacts, setContacts] = useState([]);
  const [currentChat, setCurrentChat] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  // const token = localStorage.getItem('token');


  const Container = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1rem;
  align-items: center;
  background-color: #131324;
  .container {
    height: 85vh;
    width: 85vw;
    background-color: #00000076;
    display: grid;
    grid-template-columns: 25% 75%;
    @media screen and (min-width: 720px) and (max-width: 1080px) {
      grid-template-columns: 35% 65%;
    }
  }`;

  useEffect(() => {
    const fetchUser = async () => {
      const token = await localStorage.getItem("token");
      if (!token) {
        navigate("/login");
      } else {
        try {
          const decodedUser = await jwtDecode(token); // Αποκωδικοποιείς το token
          setCurrentUser(decodedUser); // Βάζεις τον χρήστη στο state
        } catch (error) {
          console.error("Invalid token:", error);
          navigate("/login");
        }
      }
    };
    fetchUser();
  }, [navigate]);

  useEffect(() => {
    if (currentUser) {
      socket.current = io(host);
      socket.current.emit("add-user", currentUser.id);
    }
  }, [currentUser]);



  useEffect(async () => {
    if (currentUser) {
    
      const data = await axios.get(`${allUsersRoute}/${currentUser.id}`);
      setContacts(data.data);
    }
  }, [currentUser]);


    const handleChatChnage = (chat) => {
      setCurrentChat(chat);
    }

return (
  <>
  <Container>
    {/* <div className="container">
      <Contacts contacts={contacts} changeChat={handleChatChnage} />
      {currentChat === undefined ? (
        <Welcome />
      ) : (
        <ChatContainer currentChat={currentChat} socket={socket} />
      )}
      
    </div> */}
  </Container>
  </>
);
};

export default Chat;


































// const socket = io("http://localhost:5000");

// const ChatRoom = ({ roomName, user }) => {
//   const [message, setMessage] = useState("");
//   const [messages, setMessages] = useState([]);

//   useEffect(() => {
//     socket.emit("joinRoom", roomName);

//     socket.on("message", (data) => {
//       setMessages((prev) => [...prev, data]);
//     });

//     return () => {
//       socket.disconnect();
//     };
//   }, [roomName]);

//   const sendMessage = () => {
//     socket.emit("message", { room: roomName, message, user });
//     setMessage("");
//   };

//   return (
//     <div>
//       <h1>ChatRoom : {roomName}</h1>
//       <div>
//         {messages.map((msg, index) => (
//           <p key={index}>
//             <strong>{msg.user}: </strong>
//             {msg.message}
//           </p>
//         ))}
//       </div>
//       <input
//         value={message}
//         onChange={(e) => setMessage(e.target.value)}
//         placeholder="Type Your Message"
//       />
//       <button onclick={sendMessage}>Send</button>
//     </div>
//   );
// };
// export default ChatRoom;
