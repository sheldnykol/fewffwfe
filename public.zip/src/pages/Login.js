import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Αν χρησιμοποιείς React Router
import { loginRoute } from "../utils/APIRoutes";



const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate(); // Για ανακατεύθυνση μετά το login

  const handleLogin = async () => {
    try {
      const  response  = await axios.post(
        loginRoute,
        {
          email,
          password,
        }
      );
      // Αποθήκευση του token στο localStorage
      
        
      localStorage.setItem("token", response.data.token);
       console.log(response.data.token);
      // Ανακατεύθυνση στο dashboard
      navigate("/");
    
    } catch (err) {
      setError("Invalid email or password");
      console.error(err);
    }
  };

  const handleRegister = () => {
    navigate("/register");
  };
  return (
    <div>
      <h1>Login</h1>
      <form
        onSubmit={(e) => {
          e.preventDefault(); // Αποτρέπει την ανανέωση της σελίδας
          handleLogin();
        }}
      >
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Login</button>
      </form>
      <p> Not registred? </p>
      <button onClick={handleRegister}>Register Now</button>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
};

export default Login;
