import React, { useEffect, useState } from 'react';
import { getItems, addItem } from '../utils/APIRoutes';

const Dashboard = () => {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState('');
  const token = localStorage.getItem('token'); // Υποθέτουμε ότι αποθηκεύεται εδώ το token

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await getItems(token);
        setItems(response.data); // Φέρνουμε τα items του χρήστη
      } catch (error) {
        console.error('Error fetching items:', error);
      }
    };

    fetchItems();
  }, [token]);

  const handleAddItem = async () => {
    try {
      const item = { name: newItem };
      const token = localStorage.getItem('token'); // Πάρε το token από το localStorage
      const response = await addItem(item, token); // Περάστε το token στη συνάρτηση addItem
      setItems((prevItems) => [...prevItems, response.data]); // Προσθέτουμε το νέο item
      setNewItem('');
    } catch (error) {
      console.error('Error adding item:', error);
    }
  };
  

  return (
    <div>
      <h1>My Items</h1>
      <input
        type="text"
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
        placeholder="Add new item"
      />
      <button onClick={handleAddItem}>Add Item</button>
      <ul>
        {items.map((item) => (
          <li key={item._id}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
