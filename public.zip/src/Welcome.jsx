import React, { useState, useEffect } from "react";
import styled from "styled-components";
// import Robot from "../assets/robot.gif";
import { jwtDecode } from "jwt-decode"; // Βιβλιοθήκη JWT decode

export default function Welcome() {
  const [userName, setUserName] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      const decodedToken = jwtDecode(token); // Αποκωδικοποίηση του token για να πάρουμε τα δεδομένα του χρήστη
      setUserName(decodedToken.username); // Ορίζουμε το username από το αποκωδικοποιημένο token
    } else {
      // Αν δεν υπάρχει token, μπορείς να ανακατευθύνεις τον χρήστη στο login ή να κάνεις άλλες ενέργειες
      console.log("No token found. Redirect to login.");
    }
  }, []);

  return (
    <Container>
      {/* <img src={Robot} alt="robot" /> */}
      <h1>
        Welcome, <span>{userName}!</span>
      </h1>
      <h3>Please select a chat to start messaging.</h3>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  flex-direction: column;
  img {
    height: 20rem;
  }
  span {
    color: #4e0eff;
  }
`;
