const jwt = require("jsonwebtoken");
const JWT_SECRET = "your_secret_key";

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  console.log(`authHeader :  ${authHeader} \n `);

  if (!authHeader) {
    return res.status(401).json({ error: "Authorization header missing" });
  }

  const token = authHeader.split(" ")[1];
  console.log(`token : ${token} \n `);

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log(`decoded :  \n`);
    console.log(decoded);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Invalid token" });
  }
};

module.exports = authMiddleware;

//loipon
//exw to secret key kai meta
