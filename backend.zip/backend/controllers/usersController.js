const User = require("../models/userModel");
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken");
const JWT_SECRET = "your_secret_key";




//login
module.exports.login = async (req, res, next) => {

    
      try {
      const { email, password } = req.body;
        // Find the user by email
        const user = await User.findOne({ email });
        console.log(user);
        if (!user) {
          return res.status(404).json({ error: "User not found" });
        }
    
        // Compare passwords
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
          return res.status(401).json({ error: "Invalid password" });
        }
    
        // Generate a token
        const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "1h" });
        console.log("\n\n\n token ---:");
        console.log(token);
        return res.json({ token }); // ΣΗΜΑΝΤΙΚΟ: Χρησιμοποίησε return εδώ.
      } catch (error) {
        return res.status(500).json({ error: error.message }); // Χρησιμοποίησε return εδώ.
      }
    };

    //Register

    module.exports.register = async (req,res, next) => {
          try {
            const { username, email, password } = req.body;
            // Hash the password
            console.log(req);
            console.log(res);
            console.log("Request Body:", req.body);
            const hashedPassword = await bcrypt.hash(password, 10);
        
            // create a new user
            const user = new User({
              username,
              email,
              password: hashedPassword,
            });
            console.log("user", user);
            const savedUser = await user.save();
            console.log("saved user ", savedUser);
            res.status(201).json(savedUser);
          } catch (error) {
            res.status(400).json({ error: error.message });
          }
    }

    //get all users $ne (not equal)
    module.exports.getAllUsers = async (req, res , next) => {
        try {
            const users = await User.find({_id : { $ne: req.params.id } }).select([
                "email",
                "username",
                "avatarImage",
                "_id",

            ]);
            return res.json(users);
        }catch(ex) {
            next(ex);
        }
    }

    //set avatar
    module.exports.setAvatar = async (req,res,next) => {
        try {
            const userId = req.params.id ;
            const avatarImage = req.body.image;
            const userData = await User.findByIdAndUpdate(
                userId,
                {
                    isAvatarImageSet:true,
                    avatarImage,

                },
                {new : true}
            );
            return res.json({
                isSet : userData.isAvatarImageSet,
                image: userData.avatarImage,
            });
        } catch (ex) {
            next(ex);
        }
    };