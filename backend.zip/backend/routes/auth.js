
// Register a new user
const {
  login,
  register,
  getAllUsers,
  setAvatar,
} = require("../controllers/usersController");


const router = require("express").Router(); 
//Register
router.post("/register", register);

// Login a user
router.post("/login", login);


router.get("/allusers/:id", getAllUsers);

router.post("/setavatar/:id", setAvatar);


module.exports = router;
