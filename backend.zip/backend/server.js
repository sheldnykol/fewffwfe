const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const authRoutes = require("./routes/auth");
const messageRoutes = require("./routes/messages");
const bodyParser = require("body-parser");
const app = express();
const PORT = 5000;
const socket = require("socket.io")

//connect to database
// connect to MongoDB

app.use(cors());
app.use(express.json());


mongoose
  .connect(
    "mongodb+srv://georgekolonas23:OcCwZ3JlGvrOZlm3@cluster0.30eoa.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => console.log("MongoDb Connected"))
  .catch((err) => console.log(err));

app.use("/api/auth", authRoutes);
app.use("/api/messages", messageRoutes);


//Middleware

app.use(bodyParser.json());


// //Routes
// const apiRoutes = require("./routes/api");
// app.use("/api", apiRoutes);

// const authRoutes = require("./routes/auth");
// app.use("/api/auth", authRoutes);

// const roomRoutes = require("./routes/room");
// app.use("api/rooms", roomRoutes);

//Start server Port
const server = app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

//Κάθε αίτημα που ξεκινάει με /api (π.χ., /api/login, /api/items) θα κατευθυνθεί στο αρχείο api.js.
//Μέσα στο api.js, καθορίζεις τα routes (π.χ., router.post('/login', ...), router.get('/items', ...)).

const io = socket(server, {
  cors: {
    origin : "http://localhost:3000",
    credentials: true,
  },
});

global.onlineUsers = new Map();
io.on("connection", (socket) => {
  global.chatSocket = socket;
  socket.on("add-user", (UserId) => {
    onlineUsers.set(userId, socket.id);
  });


  socket.on("send-msg", (data) => {
    const sendUserSocket = onlineUsers.get(data.to);
    if(sendUserSocket) {
      socket.to(sendUserSocket).emit("msg-recieve",data.msg);
    }
  })
})
